import parid_helpers

parid_helpers.consume_parids()
